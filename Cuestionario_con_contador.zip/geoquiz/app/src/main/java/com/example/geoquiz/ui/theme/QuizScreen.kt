package com.example.geoquiz.ui.theme

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.geoquiz.QuizViewModel

@Composable
fun QuizScreen(viewModel: QuizViewModel) {
    val currentIndex = viewModel.currentIndex.collectAsState()
    val feedback = viewModel.feedback.collectAsState()
    val correctAnswers = viewModel.correctAnswers.collectAsState()

    // Obtener la pregunta basada en el índice reactivo
    val question = viewModel.getQuestionAt(currentIndex.value)
    val questionText = stringResource(id = question.textResId)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Pregunta centrada
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = questionText,
                style = MaterialTheme.typography.headlineSmall,
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Botones True / False
        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Button(onClick = { viewModel.answerQuestion(true) }) {
                Text("TRUE")
            }
            Button(onClick = { viewModel.answerQuestion(false) }) {
                Text("FALSE")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Botones de navegación
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Button(onClick = { viewModel.previousQuestion() }) {
                Text("◀")
            }
            Button(onClick = { viewModel.nextQuestion() }) {
                Text("▶")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Mensaje Correct / Incorrect
        feedback.value?.let {
            Text(
                text = it,
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Conteo de respuestas correctas
        Text(
            "Correct answers: ${correctAnswers.value}",
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center
        )
    }
}